# Devon Griffith
# March 9, 2018
#

import pygame
from scripts.NPC import *

pygame.init()

class Player:

    def __init__(self, name):
        self.name = name
        self.facing = "south"
        self.health = 100
        sprite = pygame.image.load("graphics/warrior.png")
        size = sprite.get_size()
        self.width = size[0]
        self.height = size[1]

        # GET PLAYER FACES
        self.faces = get_faces(sprite)

    def render(self, surface, pos):
        surface.blit(self.faces[self.facing], (pos[0], pos[1]))
