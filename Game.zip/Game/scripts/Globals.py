# Devon Griffith
# March 9 2018
#

class Globals:

    camera_x = 0
    camera_y = 0
    camera_move = 0
    scene = "menu"
    numPlayers = 1
    player2_x = 0
    player2_y = 0
    delta_time = 0
    numberPotions = 0
    numberKeys = 0

    dialog_open = False
    active_dialog = None
