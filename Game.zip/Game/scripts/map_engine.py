"""
Meloonatic Melons
HPMRA Map File Loader
By Harry Hitchen
"""

import pygame
from scripts.textures import *


class Map_Engine:

    def add_tile(tile, pos, addTo):
        addTo.blit(tile, (pos[0] * Tiles.Size, pos[1] * Tiles.Size))

    def add_item(item, pos2, addTo):
        addTo.blit(item, (pos2[0] * Items.Size, pos2[1] * Tiles.Size))

    def load_map(file):
        with open(file, "r") as mapfile:
            map_data = mapfile.read()

        # Read Map Data
        map_data = map_data.split("-")   # Split into list of tiles

        map_size = map_data[len(map_data) - 1]   # Get map dimensions
        map_data.remove(map_size)
        map_size = map_size.split(",")
        map_size[0] = int(map_size[0]) * Tiles.Size
        map_size[1] = int(map_size[1]) * Tiles.Size

        tiles = []

        for tile in range(len(map_data)):
            map_data[tile] = map_data[tile].replace("\n", "")
            tiles.append(map_data[tile].split(":"))   # Split pos from texture

        for tile in tiles:
            tile[0] = tile[0].split(",")   # Split pos into list
            pos = tile[0]
            for p in pos:
                pos[pos.index(p)] = int(p)   # Convert to integer

            tiles[tiles.index(tile)] = (pos, tile[1])   # Save to tile list

        tile_data = tiles


        # Create Terrain
        terrain = pygame.Surface(map_size, pygame.HWSURFACE)

        for tile in tiles:
            if tile[1] in Tiles.Texture_Tags:
                Map_Engine.add_tile(Tiles.Texture_Tags[tile[1]], tile[0], terrain)

            if tile[1] in Tiles.Blocked_Types:
                Tiles.Blocked.append(tile[0])

        return terrain


    def load_items(file):
        with open(file, "r") as itemfile:
            item_data = itemfile.read()

        item_data = item_data.split("-")

        item_size = item_data[len(item_data) - 1]
        item_data.remove(item_size)
        item_size = item_size.split(",")
        item_size[0] = int(item_size[0]) * Items.Size
        item_size[1] = int(item_size[1]) * Items.Size

        items = []


        for item in items:
            item[0] = item[0].split(",")
            pos2 = item[0]
            for i in pos2:
                pos2[pos2.index(i)] = int(i)

            items[items.index(item)] = (pos2, item[1])

        item_data = items

        item_locations = pygame.Surface(item_size, pygame.HWSURFACE)

        for item in items:
            if item[1] in Items.Item_Tags:
                Map_Engine.add_item(Items.Item_Tags[item[1]], item[0], item_locations)

        return item_locations
